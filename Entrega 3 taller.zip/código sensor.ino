// =============================================
// Proyecto: Sensor Calidad de Aire en Salas
// Grupo 9 - Sección 2
// Descripción: Monitor de calidad del aire usando ESP32-S3,
// sensor MQ135 y semáforo LED. Los datos se muestran en tiempo
// real (página web local) y se guardan en Firebase (histórico).
//
// Arquitectura robusta:
//  - El sensor y el semáforo funcionan SIEMPRE, aunque se caiga el WiFi.
//  - Firebase es "best effort": manda cuando hay internet y no bloquea
//    nada si el hotspot se corta. El loop nunca se congela.
// =============================================

// ----- Modulos de Firebase que usamos -----
#define ENABLE_USER_AUTH
#define ENABLE_DATABASE

// Librerías
#include <WiFi.h>
#include <WebServer.h>
#include <WiFiClientSecure.h>
#include <FirebaseClient.h>
#include <time.h>            // hora real (timestamp) via NTP

// --- Definición de pines ---
#define MQ135_PIN 5   // Pin analógico donde está conectado el sensor MQ135
#define PIN_R 16      // Pin del LED rojo del semáforo
#define PIN_Y 17      // Pin del LED amarillo del semáforo
#define PIN_G 18      // Pin del LED verde del semáforo

// --- Configuración WiFi ---
// Ahora el ESP32 se CONECTA a una red (el hotspot del celular)
// para tener salida a internet y poder mandar a Firebase.
const char* ssid     = "iPhone de Joaquin";
const char* password = "kira1000";

// --- Credenciales Firebase (se obtienen en la consola de Firebase) ---
#define Web_API_KEY   "AIzaSyA7brBOSY-N5zCI58AY3nN2k2A29uRaIvw"
#define DATABASE_URL  "https://calidad-aire-g9-default-rtdb.firebaseio.com/"   // ej: https://miproyecto-default-rtdb.firebaseio.com/
#define USER_EMAIL    "esp32@calidad.com"
#define USER_PASS     "sensor123"

// Servidor web local (sigue disponible como respaldo de la demo)
WebServer server(80);

// --- Objetos de Firebase ---
void processData(AsyncResult &aResult);
UserAuth user_auth(Web_API_KEY, USER_EMAIL, USER_PASS);
FirebaseApp app;
WiFiClientSecure ssl_client;
using AsyncClient = AsyncClientClass;
AsyncClient aClient(ssl_client);
RealtimeDatabase Database;

// --- Variables globales ---
int ultimoRaw = 0;
String ultimaCalidad = "Iniciando...";
String ultimoColor = "gray";
String estadoNube = "Conectando...";   // se muestra en la web

// --- Parámetros de tiempo (loop NO bloqueante) ---
const unsigned long INTERVALO_MS = 3000;        // medir + actualizar "actual"
const unsigned long INTERVALO_HIST_MS = 60000;  // guardar histórico cada 60 s
unsigned long ultimaMedicion = 0;
unsigned long ultimoHistorico = 0;              // <- nueva
unsigned long ultimoIntentoWiFi = 0;

// --- Función para controlar el semáforo LED ---
void setLED(bool r, bool y, bool g) {
  digitalWrite(PIN_R, r);
  digitalWrite(PIN_Y, y);
  digitalWrite(PIN_G, g);
}

// --- Página web local (igual que antes + estado de la nube) ---
void handleRoot() {
  String html = R"(
<!DOCTYPE html>
<html>
<head>
  <meta charset='UTF-8'>
  <meta name='viewport' content='width=device-width, initial-scale=1'>
  <meta http-equiv='refresh' content='3'>
  <title>Calidad del Aire</title>
  <style>
    body { font-family: Arial, sans-serif; background: #1a1a2e; color: white; text-align: center; padding: 20px; }
    h1 { font-size: 24px; margin-bottom: 5px; }
    h2 { font-size: 14px; color: #aaa; font-weight: normal; margin-bottom: 30px; }
    .card { background: #16213e; border-radius: 16px; padding: 30px; margin: 16px auto; max-width: 340px; }
    .raw { font-size: 64px; font-weight: bold; margin: 10px 0; }
    .label { font-size: 13px; color: #aaa; margin-bottom: 6px; }
    .estado { font-size: 22px; font-weight: bold; margin-top: 10px; }
    .indicador { width: 80px; height: 80px; border-radius: 50%; margin: 16px auto; }
    .verde   { background: #22c55e; box-shadow: 0 0 24px #22c55e88; }
    .amarillo{ background: #eab308; box-shadow: 0 0 24px #eab30888; }
    .rojo    { background: #ef4444; box-shadow: 0 0 24px #ef444488; }
    .gray    { background: #555; }
    .nube    { font-size: 12px; color: #6ab0ff; margin-top: 10px; }
    .footer  { font-size: 12px; color: #555; margin-top: 30px; }
  </style>
</head>
<body>
  <h1>Monitor Calidad del Aire</h1>
  <h2>Grupo 9 — Sección 2</h2>
  <div class='card'>
    <div class='label'>Valor del sensor (RAW)</div>
    <div class='raw'>)" + String(ultimoRaw) + R"(</div>
    <div class='indicador )" + ultimoColor + R"('></div>
    <div class='estado'>)" + ultimaCalidad + R"(</div>
    <div class='nube'>Nube: )" + estadoNube + R"(</div>
  </div>
  <div class='footer'>Actualiza cada 3 segundos</div>
</body>
</html>
)";
  server.send(200, "text/html", html);
}

// ===================================================================
//  SETUP
// ===================================================================
void setup() {
  Serial.begin(115200);

  // ADC del ESP32-S3
  analogReadResolution(12);
  analogSetAttenuation(ADC_11db);

  // Pines del semáforo
  pinMode(PIN_R, OUTPUT);
  pinMode(PIN_Y, OUTPUT);
  pinMode(PIN_G, OUTPUT);
  setLED(false, false, false);

  // Conexión WiFi (modo estación: nos conectamos al hotspot)
  conectarWiFi();
  sincronizarHora();
  iniciarFirebase();

  // Servidor web local (respaldo de la demo)
  server.on("/", handleRoot);
  server.begin();
  Serial.println("Servidor web local listo!");

  // Calentamiento del MQ135 (necesita estabilizarse)
  Serial.println("Calentando MQ135 30s...");
  delay(30000);
  Serial.println("Listo!\n");
}

// ===================================================================
//  LOOP (no bloqueante)
// ===================================================================
void loop() {
  // Estas tres líneas DEBEN correr en cada iteración:
  app.loop();             // mantiene vivo el cliente async de Firebase
  server.handleClient();  // atiende la página web local
  revisarWiFi();          // reconecta si se cayó el hotspot (sin bloquear)

  // Medición + envío cada INTERVALO_MS (usando millis, sin delay largo)
  if (millis() - ultimaMedicion >= INTERVALO_MS) {
    ultimaMedicion = millis();

    medirYClasificar();   // captura + semáforo (SIEMPRE, haya o no internet)

    // Envío a la nube SOLO si Firebase está autenticado y listo.
    // Si no hay internet, simplemente no se manda y el resto sigue igual.
   if (app.ready()) {
      enviarActual();                    // valor en vivo, cada 3 s
      estadoNube = "Sincronizando OK";
      if (millis() - ultimoHistorico >= INTERVALO_HIST_MS) {
        ultimoHistorico = millis();
        enviarHistorico();
      }
    } else {
      estadoNube = "Sin conexion (midiendo local)";
    }
  }
}

// ===================================================================
//  CAPTURA Y CLASIFICACIÓN (independiente de la red)
// ===================================================================
void medirYClasificar() {
  // Promedio de 10 lecturas para reducir ruido (~100 ms, breve)
  int suma = 0;
  for (int i = 0; i < 10; i++) {
    suma += analogRead(MQ135_PIN);
    delay(10);
  }
  ultimoRaw = suma / 10;

  Serial.print("RAW: ");
  Serial.print(ultimoRaw);
  Serial.print("  ->  ");

  // Umbrales calibrados con mediciones reales en sala cerrada
  if (ultimoRaw < 600) {
    setLED(false, false, true);
    ultimaCalidad = "BUENA — Aire limpio";
    ultimoColor = "verde";
  } else if (ultimoRaw < 800) {
    setLED(false, true, false);
    ultimaCalidad = "REGULAR — Aire aceptable";
    ultimoColor = "amarillo";
  } else {
    setLED(true, false, false);
    ultimaCalidad = "MALA — Ventila la sala!";
    ultimoColor = "rojo";
  }
  Serial.println(ultimaCalidad);
}

// ===================================================================
//  RED Y FIREBASE
// ===================================================================
void conectarWiFi() {
  WiFi.mode(WIFI_STA);
  WiFi.begin(ssid, password);
  Serial.print("Conectando a WiFi");
  int intentos = 0;
  while (WiFi.status() != WL_CONNECTED && intentos < 20) {
    Serial.print(".");
    delay(500);
    intentos++;
  }
  Serial.println();
  if (WiFi.status() == WL_CONNECTED) {
    Serial.print("WiFi OK. IP: ");
    Serial.println(WiFi.localIP());   // IP del dashboard local en el hotspot
  } else {
    Serial.println("Sin WiFi por ahora (se reintenta en el loop).");
  }
}

// Reconexión no bloqueante: si se cae el hotspot, reintenta cada 10 s
// sin congelar el resto del programa.
void revisarWiFi() {
  if (WiFi.status() != WL_CONNECTED && millis() - ultimoIntentoWiFi > 10000) {
    ultimoIntentoWiFi = millis();
    Serial.println("WiFi caido, reintentando...");
    WiFi.disconnect();
    WiFi.begin(ssid, password);
  }
}

void sincronizarHora() {
  // GMT-4 (Chile continental). Ajusta el offset si cambia el horario.
  configTime(-4 * 3600, 0, "pool.ntp.org", "time.nist.gov");
  struct tm timeinfo;
  int intentos = 0;
  while (!getLocalTime(&timeinfo) && intentos < 10) {
    delay(500);
    intentos++;
  }
}

// Texto legible para mostrar/guardar: "2026-06-11 14:30:00"
String obtenerTimestamp() {
  struct tm timeinfo;
  if (!getLocalTime(&timeinfo)) return String(millis());
  char buf[25];
  strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M:%S", &timeinfo);
  return String(buf);
}

// Versión sin caracteres prohibidos por Firebase ( . # $ [ ] / espacios )
// para usar como clave del nodo histórico: "2026-06-11_14-30-00"
String obtenerClaveTimestamp() {
  struct tm timeinfo;
  if (!getLocalTime(&timeinfo)) return String(millis());
  char buf[25];
  strftime(buf, sizeof(buf), "%Y-%m-%d_%H-%M-%S", &timeinfo);
  return String(buf);
}

void iniciarFirebase() {
  ssl_client.setInsecure();   // sin validar certificado (suficiente para el proyecto)
  ssl_client.setConnectionTimeout(1000);
  ssl_client.setHandshakeTimeout(5);

  initializeApp(aClient, app, getAuth(user_auth), processData, "authTask");
  app.getApp<RealtimeDatabase>(Database);
  Database.url(DATABASE_URL);
}

// Construye el JSON de la lectura actual
object_t armarJson() {
  object_t json, oRaw, oCalidad, oColor, oTs;
  JsonWriter writer;
  writer.create(oRaw,     "raw",       ultimoRaw);
  writer.create(oCalidad, "calidad",   ultimaCalidad);
  writer.create(oColor,   "color",     ultimoColor);
  writer.create(oTs,      "timestamp", obtenerTimestamp());
  writer.join(json, 4, oRaw, oCalidad, oColor, oTs);
  return json;
}

// Sobrescribe el valor en vivo (cada 3 s)
void enviarActual() {
  Database.set<object_t>(aClient, "/sensor/actual", armarJson(), processData, "SetActual");
}

// Guarda un registro en el histórico (cada 60 s)
void enviarHistorico() {
  String pathHist = "/sensor/historico/" + obtenerClaveTimestamp();
  Database.set<object_t>(aClient, pathHist.c_str(), armarJson(), processData, "SetHist");
}

// Callback: reporta errores de Firebase sin frenar el programa
void processData(AsyncResult &aResult) {
  if (!aResult.isResult()) return;
  if (aResult.isError()) {
    Firebase.printf("Error %s: %s (cod %d)\n",
                    aResult.uid().c_str(),
                    aResult.error().message().c_str(),
                    aResult.error().code());
  }
}
